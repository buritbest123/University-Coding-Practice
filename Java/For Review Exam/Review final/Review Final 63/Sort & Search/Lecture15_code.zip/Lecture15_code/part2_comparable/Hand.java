package part2_comparable;

public class Hand {

}
