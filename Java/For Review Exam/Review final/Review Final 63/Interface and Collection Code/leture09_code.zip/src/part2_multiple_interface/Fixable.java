package part2_multiple_interface;

public interface Fixable {
	final String ERROR = "Cannot fix";
	
	boolean fix();
}

