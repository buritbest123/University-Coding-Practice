package part2_multiple_interface;

public interface Skyability {
	
	public abstract void fly();
	
}
