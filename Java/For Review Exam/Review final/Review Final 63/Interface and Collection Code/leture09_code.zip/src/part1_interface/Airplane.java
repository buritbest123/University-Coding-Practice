package part1_interface;

public class Airplane implements Skyability{

	@Override
	public void fly() {
		System.out.println("Flying with engines");
	}

}
