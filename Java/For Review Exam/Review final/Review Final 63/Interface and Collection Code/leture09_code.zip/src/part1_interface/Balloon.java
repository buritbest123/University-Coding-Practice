package part1_interface;

public class Balloon implements Skyability{

	@Override
	public void fly() {
		System.out.println("Flying with hot-air");
	}

}
