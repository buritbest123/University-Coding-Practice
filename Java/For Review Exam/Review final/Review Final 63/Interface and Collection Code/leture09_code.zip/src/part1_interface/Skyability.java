package part1_interface;

public interface Skyability {
	
	public abstract void fly();
	
}
