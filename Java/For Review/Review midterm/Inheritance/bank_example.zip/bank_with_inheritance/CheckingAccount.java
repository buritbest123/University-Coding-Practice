package bank_with_inheritance;;

public class CheckingAccount extends BankAccount{
	
	public CheckingAccount() {
		super();
	}
	
	public CheckingAccount(double balance) {
		super(balance);
	}
}
