package part6_clone;


public class Animal {	// default extends Object
	public String name;
	
	public Animal(String n){
		this.name = n;
	}
	
	/*
	@Override
	public String toString(){
		return "name: " + name;
	}
	*/
}
